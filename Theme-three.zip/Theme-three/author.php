
<!-- Carmen - shows all posts of the author selected-->
<?php
get_header();
?>



<main>
    <section>
	  <div class="container" >
		<div class="row">
						<div>
							<h1> <?php the_author(); ?></h1>

<?php
if ( have_posts() ){

    while ( have_posts() ){

         the_post();
         get_template_part('template-parts/content', 'archive' );
    }
}
?>


<nav class="navigation pagination">
<?php
                the_posts_pagination([
                    "prev_text" => "Föregoende",
                    "next_text" => "Nästa"
				]);
		?>
							</nav>
						</div>
						
									
					</div>
				</div>
			</section>
		</main>
			


<?php
get_footer();
?>
 




    

