<!-- Carmen, display by category -->

<?php
get_header();
?>



<main>
   <section>
	  <div class="container" >
		<div class="row">
					<div >
						<div>
							<h1><?php single_cat_title(); ?></h1>

<?php
if ( have_posts() ){

    while ( have_posts() ){

         the_post();
         get_template_part('template-parts/content', 'archive' );
    }
}
?>


<nav class="navigation pagination">
<?php
                the_posts_pagination([
                    "prev_text" => "Föregoende",
                    "next_text" => "Nästa"
				]);
		?>
							</nav>
						</div>
						
					</div>
				</div>
			</section>
		</main>
			


<?php
get_footer();
?>
 




    

