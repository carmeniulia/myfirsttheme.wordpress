<!-- Carmen 3 sections footer, with widgets and functions -->

<footer>
			<div class="container">
				<div class="row top">
					<div class="col-xs-12 col-sm-6 col-md-4">
					<?php
if(is_active_sidebar('footer-1')){
dynamic_sidebar('footer-1');
}
?>

					</div>
					<div class="col-xs-12 col-sm-3 col-md-3 col-md-offset-1">
					<?php
if(is_active_sidebar('footer-2')){
dynamic_sidebar('footer-2');
}
?>
					</div>
					<div class="col-xs-12 col-sm-3 col-md-3 col-md-offset-1">
					<?php
if(is_active_sidebar('footer-3')){
dynamic_sidebar('footer-3');
} ?>
					</div>
				</div>
	         </div>
		  </div>
		</div>
	</footer>
		



<?php
    wp_footer();
?>

</body>
</html>