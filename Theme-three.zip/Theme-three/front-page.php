<!-- Carmen -->
<?php
get_header();
?>

<?php
	$testimonialred = get_field('testimonial_red'); 
	
?>

<main>

<!-- hero section-->
	<section >
      <div >
        <?php if(have_rows("hero_hem")):?>
				<?php while (have_rows("hero_hem")): the_row(); ?>
					<?php if(get_row_layout() == "hero_it"): ?>
						<?php get_template_part("./sections/section-hero"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>			
		</div>	
	</section>

<!-- flexible section 3 rows, 3 fields-->	
<section class="columns text-center">
	<div class="container">
       <?php if(have_rows('three_rows')): ?>
          <div class="row bottom">
				<?php while(have_rows('three_rows')): the_row();
				  $logo = get_sub_field('logo_3row');
				  $title = get_sub_field('title_3row');
				  $content = get_sub_field('text_3row');
				  ?>
                        <div class="col-xs-4">
						<?php if($logo): ?>
							<img src="<?php echo $logo ?>" alt="<?php echo $logo['alt']; ?>" />
							<?php endif; ?>
							<h3><?php echo $title;?> </h3>
							<p><?php echo $content;?> </p>
						</div>
				            <?php endwhile; ?>
			
				       </div>	

                    <?php endif; ?>

				</div>
			</section>
<!-- testimonial section, simple row text-->
			<section class="testimonial-red">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-3 text-center">
							<h3><?php echo $testimonialred['text_testimonial_red']; ?></h3>
						</div>
					</div>
				</div>
			</section>

			
			<?php
	 // This is AcF gallery
	 
       // Load value (array of ids).
          $image_ids = get_field('gallery_home');
             if( $image_ids ) {

    // Generate string of ids ("123,456,789").
           $images_string = implode( ',', $image_ids );

    // Generate and do shortcode.
    // Note: The following string is split to simply prevent our own website from rendering the gallery shortcode.
    $shortcode = sprintf( '[' . 'gallery ids="%s"]', esc_attr($images_string) );
    echo do_shortcode( $shortcode );
}
			?>
			
		
</main>

<?php
get_footer();
?>
 