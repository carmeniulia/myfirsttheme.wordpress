<?php

// Register functions (Carmen)
function carmen_register_styles(){
    $version = wp_get_theme()->get( 'Version' );

	wp_enqueue_style ('carmen-style', get_stylesheet_directory_uri() . "/style.css", $version, 'all' );
	wp_enqueue_style ('carmen-font', get_stylesheet_directory_uri() . "/CSS/font-awesome.css", array(),  $version, 'all' );
	wp_enqueue_style ('carmen-bootstrap', get_stylesheet_directory_uri() . "/CSS/bootstrap.css", array(),  $version, 'all' );
}
    
	add_action('wp_enqueue_scripts', 'carmen_register_styles');
	


	function carmen_register_scripts(){
	
}

add_action('wp_enqueue_scripts', 'carmen_register_scripts');



//add dynamic title,logo,thumbnail support (Carmen)
function carmen_theme_support(){

add_theme_support('tittle-tag');
add_theme_support('custom-logo');
add_theme_support('post-thumbnails');
}

add_action('after_setup_theme','carmen_theme_support');

// menu (Carmen)
function carmen_menus(){

    $location = array(
        'primary' => "Menu",
        'footer'  => "Footer Menu"
    );
     register_nav_menus($location);
}
add_action('init', 'carmen_menus');






/**
 * Register widget area. (Nahom)
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function three_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'three' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'three' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	
		register_sidebar(
		array(
			'name'          => esc_html__( 'Page Sidebar', 'three' ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Add widgets here.', 'three' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	
}
add_action( 'widgets_init', 'three_widgets_init' );

// Set up the WordPress core custom background feature. (Nahom)
add_theme_support(
	'custom-background',
	apply_filters(
	'theme_three_custom_background_args',
	array(
	'default-color' => 'ffffff',
	'default-image' => '',
	 )
	 )
	);


// Footer Carmen

register_sidebar( array(
'name' => 'Footer Area 1',
'id' => 'footer-1',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

register_sidebar( array(
'name' => 'Footer Area 2',
'id' => 'footer-2',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

register_sidebar( array(
'name' => 'Footer Area 3',
'id' => 'footer-3',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

//Register Googel Map (Carmen) not finished
function mapLocation($api) {
	$api['key'] = 'AIzaSyDMNnYjHk9WC_xgqP5i33htI-oi2r0Lnp4';
	return $api;
}

add_filter('acf/fields/google_map/api', 'mapLocation');

