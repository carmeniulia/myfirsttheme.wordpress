<!-- Carmen -->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
	wp_head();
    ?>

</head>
<body>

<nav>
    <div>
            <ul class="menu">   
                <li>   
                  <a class="logo" href="http://localhost:8888/slutprojekt/">
                      <?php the_custom_logo(); ?>
                   </a>
                 </li>
                 <li> <h1 class="sitetitle"><?php echo get_bloginfo( 'name' ); ?></h1> </li>
       
             <li class="current-menu-item"><a><?php wp_nav_menu()?></a></li>
        <!-- Nahom searchbar-->
       <div>
        <ul>
             <div class="searchbar"><?php
                  get_search_form();?>
              </div>
        </ul>
       </div>
     </div>
     </ul>
  <!-- Carmen breadcrumbs-->   
     <div class="breadcrumbs">
	
			  <?php
              if ( function_exists('yoast_breadcrumb') ) {
              yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
              }
            ?>
     </div>       
    
  </div>
</nav>