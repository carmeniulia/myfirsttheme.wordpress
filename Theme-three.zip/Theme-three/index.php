<!-- Carmen blogg page -->

<?php
get_header();
?>



<main>
	<section>
	  <div class="container" >
		<div class="row">
			<div>	
				<h1>Blogg</h1>
				<?php
                    if ( have_posts() ){
						while ( have_posts() ){ ?>
						<div class="box-article">
						<?php
							 the_post();
							   get_template_part('template-parts/content', 'archive' ); 
						?>
					 </div>
				<?php		   
			   } 
               }
			?>
			
	<!-- Carmen pagination -->			  
         <nav>
           <?php
                the_posts_pagination([
				"prev_text" => "Föregoende",
				"next_text" => "Nästa",
				]);
		   ?>

          </nav>
<!-- Nahom sidebar -->
	</div>
						<aside id="secondary" class="col-xs-12 col-md-3">
							<div id="sidebar">
							    <?php
							    
							    get_sidebar();
							    ?>
							    
							</div>
						</aside>
					  </div>  
					</div>
				</div>
			</section>
		</main>
			

		
<?php
get_footer();
?>
 




    

