<!-- Carmen: ACF for contact page  -->

<div>
	<div class="container">
		<div class="row">
			<div class="col-xs-6 text-center">
					 <?php the_sub_field('contact_form');  ?>
			</div>
			<div class="col-xs-6 text-center">
					 <?php the_sub_field('map_contact'); ?>
			</div>
		</div>
	</div>
</div>
