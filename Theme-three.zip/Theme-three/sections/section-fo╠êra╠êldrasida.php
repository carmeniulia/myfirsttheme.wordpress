<!-- Carmen, section text + image same row-->
      <div>
		<div class="container">
			<div class="row">
							<div class="col-xs-6">
							  <?php the_sub_field('text_f');  ?>
							</div>
							<div class="col-xs-6 text-center">
						      <img src="<?php the_sub_field('bild_f'); ?>" >	
							</div>
						</div>
					</div>
				</div>

				