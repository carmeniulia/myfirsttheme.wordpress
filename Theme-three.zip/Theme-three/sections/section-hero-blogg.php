<!-- Carmen: Hero parent page  -->
<section class="hero" style= "background-image:url('<?php the_sub_field("image_blogg_hero"); ?>') ">
  <div class="container">
	<div class="row">
	   <div class="col-xs-12 column">
		   <div class="herotext">
                  <?php the_sub_field("text_blogg_hero"); ?>
          </div>
	    </div>
	 </div> 
  </div>
</section> 