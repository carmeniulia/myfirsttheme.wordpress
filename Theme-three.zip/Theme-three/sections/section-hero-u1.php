<!-- Carmen: Hero child 1 page  -->
<section class="hero" style= "background-image:url('<?php the_sub_field("image__hero_u1"); ?>') ">
  <div class="container">
	<div class="row">
	   <div class="col-xs-12 column">
		   <div class="herotext">
                  <?php the_sub_field("text_hero_u1"); ?>
          </div>
	    </div>
	 </div> 
  </div>
</section> 