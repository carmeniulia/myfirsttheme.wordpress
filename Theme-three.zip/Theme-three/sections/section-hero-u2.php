<!-- Carmen: Hero child 2 page  -->
<section class="hero" style= "background-image:url('<?php the_sub_field("image__hero_u2"); ?>') ">
  <div class="container">
	<div class="row">
	   <div class="col-xs-12 column">
		   <div class="herotext">
                  <?php the_sub_field("text_hero_u2"); ?>
          </div>
	    </div>
	 </div> 
  </div>
</section> 