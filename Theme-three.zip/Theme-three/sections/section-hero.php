<!-- Carmen, hero section Home -->
<section class="hero" style= "background-image:url('<?php the_sub_field("image_hero"); ?>') ">
  <div class="container">
	<div class="row">
	   <div class="col-xs-12 column">
		   <div class="herotext">
                  <?php the_sub_field("text_hero"); ?>
          </div>
	    </div>
	 </div> 
  </div>
</section> 