<!-- Carmen: Flexible content, 2 sections, undersida 2  -->
<div>
	<div class="container">
		<div class="row">
               <div class="col-xs-6 text-center">
			        <img src="<?php the_sub_field('image_left'); ?>" >	
				</div>
                <div class="col-xs-6 text-center">
			        <img src="<?php the_sub_field('image_right'); ?>" >	
				</div>
		</div>
	</div>
</div>
