<!-- Carmen: Section bild text undersidan 1  -->
<div>
	<div class="container">
		<div class="row">
               <div class="col-xs-6 text-center">
			        <img src="<?php the_sub_field('image_section_undersida1'); ?>" >	
				</div>
			<div class="col-xs-6 text-center">
					 <?php the_sub_field('text_section_undersida1'); ?>
			</div>
		</div>
	</div>
</div>
