<!-- Carmen -->
<?php
/* Template Name: Undersidan 1 */
get_header(); 
?>
      <main>
     
			 
	  <section >
      <div >
		<?php
		/* Hero srction */
		if(have_rows("hero_u1")):?>
				<?php while (have_rows("hero_u1")): the_row(); ?>
					<?php if(get_row_layout() == "hero_unders_ett"): ?>
						<?php get_template_part("./sections/section-hero-u1"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>			
		</div>	
	</section>
         <!-- Side menu for parent och child tempaltes -->
	          <aside id="secondary" class="col-xs-12 col-md-3">
							<ul class="side-menu">
							<?php get_template_part ("./partials/sidemenu")
		                    ?>
							</ul>
						</aside>
              
	              <section>
		     		<div class="container">
			    		<div class="row">
				    		<div id="primary" class="col-xs-12 col-md-9">
					
							<?php
                            if ( have_posts() ) { ?>
                       

                            <?php while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
                           }
						 }

                      ?>
					  </div>
					 

        <!-- Section flexible image and text  -->            
	 <section>
	      <div class="container">
			   <div class="row">
	        <?php if(have_rows("section_1")): ?>
                  <?php while(have_rows("section_1")): the_row();?>
			          <?php if(get_row_layout() == "section_2part"):?>
                  <?php get_template_part("./sections/undersida1-2section"); ?>
                <?php endif; ?>
	    	<?php endwhile; ?>
		  <?php endif; ?>
		 </div>
	   </div>
    </section>
					</div>
				</div>
			</section>

			   
	

		</main>
<?php 
get_footer();
?>