<!-- Carmen -->
<?php
/* Template Name: Undersidan 2 */
get_header(); 
?>
      <main>
	  <section >
      <div >
		<?php /* hero section */
		if(have_rows("hero_u2")):?>
				<?php while (have_rows("hero_u2")): the_row(); ?>
					<?php if(get_row_layout() == "hero_u2"): ?>
						<?php get_template_part("./sections/section-hero-u2"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>			
		</div>	
	</section>
	             <aside id="secondary" class="col-xs-12 col-md-3">
							<ul class="side-menu">
							<?php get_template_part ("./partials/sidemenu")
		                    ?>
							</ul>
						
					     </aside>
              <section>
		     		<div class="container">
			    		<div class="row">
				    		<div id="primary" class="col-xs-12 col-md-9">
                        <?php the_title( '<h1>', '</h1>' ); ?>
						
						           	<?php
                            if ( have_posts() ) { ?>
                       

                            <?php while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
                           }
                         }
                      ?>
                      </div>
                     
   <!-- Section 2 images on the same row -->
		<section>
          <div >
	        <?php if(have_rows("section_2images")): ?>
                  <?php while(have_rows("section_2images")): the_row();?>
			          <?php if(get_row_layout() == "two_images"):?>
                  <?php get_template_part("./sections/section-u2-images"); ?>
                <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	      </div>
    </section>

					</div>
				</div>
			</section>
		</main>
<?php 
get_footer();
?>