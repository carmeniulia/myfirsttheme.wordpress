
<?php
/* Template Name: About */
//* Carmen 
get_header(); 
?>

<?php
    $testimonialb = get_field('testimonial_black'); 
?>
	
      <main>
          <section >
		     		<div class="container">
			    		<div>
				    		<div id="primary" class="style-about" >
                        <?php the_title( '<h1>', '</h1>' ); ?>
                        <?php
					                    if ( have_posts() ) { ?>
                       <?php while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
                           }
                         }
                      ?>
                      </div>
        <!-- Section felxible content -->
       <section>
         <div>
	        <?php if(have_rows("testimonial_about")): ?>
           <?php while(have_rows("testimonial_about")): the_row();?>
			          <?php if(get_row_layout() == "about_testimonial"):?>
           <?php get_template_part("./sections/section-about"); ?>
           <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	   </div>
        </section>
 	 <!-- Testimonial black -->
		<section class="testimonial-black">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-3 text-center">
							<h2><?php echo $testimonialb['text_testi_balck']; ?></h2>
						</div>
					</div>
				</div>
			</section>
 <!-- Reepater team members -->
      <section>
        <?php if(have_rows('repeater_team')): ?>
					<div class="team-testimonial">
						   <?php while(have_rows('repeater_team')): the_row();
						    
						      $image = get_sub_field('image_team');
							    $name = get_sub_field('name_team');
								$text = get_sub_field('text_team');
							 ?>
						    
						<div class="col-xs-6">
							<?php if($image): ?>
							<img class="team-img" src="<?php echo $image ?>" alt="<?php echo $image['alt']; ?>" />
							<?php endif; ?>
							
							<h3><?php echo  $name ?></h3>
							<p> <?php echo  $text ?></p>

						</div>
						<?php endwhile; ?>

					</div>

				  <?php endif; ?>
			   </div>
      </section>
      
					</div>
				</div>
			</section>
		</main>
<?php 
get_footer();
?>