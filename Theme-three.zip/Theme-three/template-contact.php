<!-- Carmen -->
<?php
/* Template Name: Kontakt */
get_header(); 
?>
     <section>
            <div>
              <?php /* Hero section */
              if(have_rows("hero_contact")):?>
				      <?php while (have_rows("hero_contact")): the_row(); ?>
				     	<?php if(get_row_layout() == "hero_c"): ?>
				  		<?php get_template_part("./sections/section-contact-hero"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>			
		</div>	
	</section>
     
     <main>
      <section>
        <div class="container">
					<div class="row">
                 
          
                        <?php
					                    if ( have_posts() ) { ?>
                       <?php while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
                           }
                         }
                      ?>
                      
                  </div>
				      </div>
      </section>
    <!-- 2 sections, left contact form and right google map -->  
    <section>
       <div >
	        <?php if(have_rows("contact_section")): ?>
           <?php while(have_rows("contact_section")): the_row();?>
			          <?php if(get_row_layout() == "two_sections"):?>
           <?php get_template_part("./sections/contact-2section"); ?>
           <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	   </div>
    </section>
						
				
		</main>
<?php 
get_footer();
?>