<!-- Carmen -->
<?php
/* Template Name: Föräldrasidan Template */
get_header(); 
?>
<?php
    $testimonialf = get_field('testimonial_black_f'); 
?>

<main>
		<!-- menu aside -->
          <aside id="secondary" class="col-xs-12 col-md-3">
							<ul class="side-menu">
							<?php get_template_part ("./partials/sidemenu")
		                    ?>
							</ul>
						</aside>
       <!-- hero section -->
        <?php if(have_rows("hero_foraldrar")):?>
				<?php while (have_rows("hero_foraldrar")): the_row(); ?>
					<?php if(get_row_layout() == "hero_parent"): ?>
						<?php get_template_part("./sections/section-hero-f"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>
		<!-- Testimonial black text row -->	
			<section class="testimonial-black">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-3 text-center">
							<h3><?php echo $testimonialf['text_testimonial_f']; ?></h3>
						</div>
					</div>
				</div>
			</section>
          
           <section>
				<div class="container">
					<div class="row">
						<div id="primary" class="col-xs-12 col-md-9">
        
                        <?php
                            if ( have_posts() ){

                             while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
                     }
                   }
                 ?>
						</div>
						
					</div>
				</div>
			</section>

 <!-- Section flexible content text + image -->
  <section > 
	  <div class="flexible-section">
	    <?php if(have_rows("flexibel_f")): ?>
           <?php while(have_rows("flexibel_f")): the_row();?>
			          <?php if(get_row_layout() == "bild_text"):?>
				   <?php get_template_part("./sections/section-föräldrasida"); ?>
			          
	          <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	   </div>
	</section> 

     <!-- Repeater 6, title, text, link  -->
	<?php $sexrepeater = get_field('repeater_foraldrasida');
	      $texttile = get_field('text_title');
	?>
			<section class="columns text-center sectionsex">
				<div class="container">
				<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $texttile  ?></h2>
						</div>
					</div>
					<?php if(have_rows('repeater_foraldrasida')): ?>
					<div class="row bottom">

						   <?php while(have_rows('repeater_foraldrasida')): the_row(); 
						     $linkf = get_sub_field('link_repeater_f');
							 $titlef = get_sub_field('title_repeater_f');
							 $contentf = get_sub_field('content_repeater_f');
							 ?>
						
						<div class="col-xs-4">
							<h3><?php echo $titlef;?> </h3>
							<p><?php echo $contentf;?> </p>
						     <?php	if( $linkf ): ?>
                               <a class="button" href="<?php echo esc_url( $linkf ); ?>">Läs mer</a>
                             <?php endif; ?>
						</div>
				 <?php endwhile; ?>
			
				</div>	

		  <?php endif; ?>
	</div>
</section>


</main>
				
	 

<?php 
get_footer();
?>