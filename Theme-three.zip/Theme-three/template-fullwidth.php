<?php
/* Template Name: Sidebar */
/**
 * Nahom
 */

get_header();
?>

 
		
	<main id="primary" class="site-main"> 
	
			<section class="standard">
				<div class="container">
					<div class="row">
					    <?php 	while ( have_posts() ) : the_post();?>
						<div id="primary" class="col-xs-12 col-md-9">
							<h1><?php the_title();?></h1>
							<?php the_content();?>
						</div>
	                	<?php	endwhile;  ?> 			
						<aside id="secondary" class="col-xs-12 col-md-3">
						<?php dynamic_sidebar( 'sidebar-2' ); ?>
						</aside>
					</div>
				</div>
			</section>
	
	  
	</main><!-- #main -->

<?php 
get_footer();