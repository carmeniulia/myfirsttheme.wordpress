<!-- Carmen show singel article -->
<main>
	<section>
		<article>
             <div class="container">
	            <div class="row">
				   <div>
					<article >
					   
						<h1 class="title"><?php the_title(); ?></h1>
						
						<ul class="art" style="color:white;">
						<li>
						    <i class="fa fa-calendar"></i> <?php the_date(); ?>
						</li> 
						<li>
						  <i class="fa fa-user"></i> <?php the_author_posts_link(); ?>
						</li>
						<li>
							<i class="fa fa-tag"></i> <?php the_category( $separator = ' , ') ?>       
						</li>
                          </ul>
                      <p>
					  <?php
                            the_post_thumbnail('medium');
                         ?>
                      <?php
                       the_content();
                       ?>

					 </p>
					      </div>
					 </div> 
                </div>
          </article>
     </section>
</main>
