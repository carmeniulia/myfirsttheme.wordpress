<!-- Carmen -->
<?php
the_content();
?>