 
<?php
/**
 * Template delen för att visa resultat i sök sidor (Nahom)
 */
?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<img src="<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'post-thum' ); echo $image[0]; ?>" />
	 
		<?php the_title( sprintf( '<h2 class="title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		<ul class="meta">
			<li>
				<i class="fa fa-calendar"></i>  <?php echo get_the_date('j F, Y'); ?> 
			</li>
			<li>
				<i class="fa fa-user"></i>  <?php the_author(); ?> 
			</li>
			<li>
				<i class="fa fa-tag"></i> <?php the_category(', '); ?>
			</li>
		</ul>
		<p><?php echo wp_trim_words( get_the_content(), 60, '...' ); ?></p>
	</article>
